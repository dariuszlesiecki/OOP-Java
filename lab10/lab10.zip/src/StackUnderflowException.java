public class StackUnderflowException extends Exception{
    public StackUnderflowException(String errorMessage) {
        super(errorMessage);
    }
}
