public class OptionNotRecognizedException extends Exception{
    public OptionNotRecognizedException(String errorMessage) {
        super(errorMessage);
    }
}
