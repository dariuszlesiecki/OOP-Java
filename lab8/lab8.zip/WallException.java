public class WallException extends Exception{
    public WallException(String errorMessage) {
        super(errorMessage);
    }
}
