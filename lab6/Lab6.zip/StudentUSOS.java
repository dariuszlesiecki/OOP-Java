interface StudentUSOS {
    String toString();

    double srednia();

    void listaPrzedmiotow();
}