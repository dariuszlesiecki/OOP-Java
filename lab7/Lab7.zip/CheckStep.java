interface CheckStep {
    boolean test(char[][] board, int y, int x, Direction dir);
}